<?php $__env->startSection('title', $settings['site_name'] ?? 'Porto'); ?>

<?php $__env->startSection('content'); ?>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg fixed-top navbar-porto" id="mainNavbar">
    <div class="container">
        <a class="navbar-brand" href="#hero">
            <i class="bi bi-hexagon-fill me-2"></i><?php echo e($settings['site_name'] ?? 'Porto'); ?>

        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="#hero">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
                <li class="nav-item"><a class="nav-link" href="#skills">Skills</a></li>
                <li class="nav-item"><a class="nav-link" href="#portfolio">Portfolio</a></li>
                <li class="nav-item"><a class="nav-link" href="#experience">Experience</a></li>
                <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
                <li class="nav-item ms-lg-2 theme-toggle-li">
                    <button class="btn theme-toggle-btn" id="themeToggle" type="button" title="Toggle Dark/Light Mode">
                        <span class="theme-toggle-inner">
                            <i class="bi bi-moon-fill theme-icon-dark"></i>
                            <i class="bi bi-sun-fill theme-icon-light"></i>
                        </span>
                        <span class="theme-toggle-label">
                            <span class="label-dark">Dark Mode</span>
                            <span class="label-light">Light Mode</span>
                        </span>
                    </button>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<section class="hero-section" id="hero">
    <div class="hero-bg-shapes">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
        <div class="shape shape-3"></div>
    </div>
    <div class="container">
        <div class="row align-items-center align-content-center min-vh-100 pb-5">
            <div class="col-lg-6 hero-content" data-aos="fade-right">
                <span class="hero-badge">
                    <i class="bi bi-stars me-1"></i> Welcome to my portfolio
                </span>
                <h1 class="hero-title"><?php echo e($settings['hero_title'] ?? "Hello, I'm John Doe"); ?></h1>
                <p class="hero-subtitle"><?php echo e($settings['hero_subtitle'] ?? 'Full Stack Developer & UI/UX Designer'); ?></p>
                <p class="hero-description"><?php echo e($settings['hero_description'] ?? 'I create beautiful and functional web experiences'); ?></p>
                <div class="hero-buttons">
                    <a href="#portfolio" class="btn btn-primary-custom btn-lg">
                        <i class="bi bi-collection me-2"></i>View My Work
                    </a>
                    <a href="#contact" class="btn btn-outline-custom btn-lg">
                        <i class="bi bi-envelope me-2"></i>Contact Me
                    </a>
                </div>
                <div class="hero-social">
                    <?php $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($link->url); ?>" target="_blank" class="hero-social-link" title="<?php echo e($link->platform); ?>">
                            <i class="bi bi-<?php echo e($link->icon); ?>"></i>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-lg-6 hero-image-col" data-aos="fade-left">
                <?php if(!empty($settings['hero_image'])): ?>
                    <div class="hero-image-wrapper">
                        <div class="hero-image-frame">
                            <img src="<?php echo e(asset($settings['hero_image'])); ?>" alt="Hero" class="hero-image" fetchpriority="high">
                        </div>
                        <div class="hero-image-decoration"></div>
                    </div>
                <?php else: ?>
                    <div class="hero-image-wrapper">
                        <div class="hero-image-placeholder">
                            <i class="bi bi-person-workspace"></i>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- About Section -->
<section class="section-padding bg-light-custom" id="about">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5 mb-4 mb-lg-0" data-aos="fade-right">
                <div class="about-image-wrapper">
                    <?php if(!empty($settings['about_image'])): ?>
                        <img src="<?php echo e(asset($settings['about_image'])); ?>" alt="About Me" class="about-image">
                    <?php else: ?>
                        <div class="about-image-placeholder">
                            <i class="bi bi-person-circle"></i>
                        </div>
                    <?php endif; ?>
                    <div class="about-image-dots"></div>
                </div>
            </div>
            <div class="col-lg-7" data-aos="fade-left">
                <span class="section-badge">
                    <i class="bi bi-person me-1"></i> Get to know me
                </span>
                <h2 class="section-title"><?php echo e($settings['about_title'] ?? 'About Me'); ?></h2>
                <p class="about-text"><?php echo e($settings['about_description'] ?? 'I am a passionate developer.'); ?></p>
                <?php if(!empty($settings['hero_cv'])): ?>
                    <a href="<?php echo e(asset($settings['hero_cv'])); ?>" class="btn btn-primary-custom" download>
                        <i class="bi bi-download me-2"></i>Download CV
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- Skills Section -->
<section class="section-padding" id="skills">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-up">
            <span class="section-badge">
                <i class="bi bi-lightning me-1"></i> What I do
            </span>
            <h2 class="section-title">My Skills</h2>
        </div>
        <div class="row g-4">
            <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 100); ?>">
                    <div class="skill-card h-100">
                        <div class="skill-card-header">
                            <?php if($skill->icon): ?>
                                <div class="skill-icon">
                                    <i class="bi bi-<?php echo e($skill->icon); ?>"></i>
                                </div>
                            <?php endif; ?>
                            <div class="skill-info">
                                <h5 class="skill-name mb-0"><?php echo e($skill->name); ?></h5>
                            </div>
                        </div>
                        <?php if($skill->description): ?>
                            <div class="skill-description mt-3 text-muted" style="font-size: 0.9rem;">
                                <?php echo e($skill->description); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!-- Portfolio Section -->
<section class="section-padding bg-light-custom" id="portfolio">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-up">
            <span class="section-badge">
                <i class="bi bi-briefcase me-1"></i> My work
            </span>
            <h2 class="section-title">Portfolio</h2>
            <p class="section-subtitle">A selection of projects I've built and shipped</p>
        </div>

        <!-- Filter Buttons -->
        <?php
            $categories = $portfolios->pluck('category')->unique()->filter();
        ?>
        <?php if($categories->count() > 0): ?>
            <div class="portfolio-filters text-center mb-5" data-aos="fade-up">
                <button class="filter-btn active" data-filter="all">All</button>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button class="filter-btn" data-filter="<?php echo e(\Illuminate\Support\Str::slug($category)); ?>"><?php echo e($category); ?></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <div class="row g-4 portfolio-grid" id="portfolioGrid">
            <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4 portfolio-item <?php echo e($index >= 6 ? 'portfolio-hidden' : ''); ?>"
                     data-category="<?php echo e(\Illuminate\Support\Str::slug($portfolio->category)); ?>"
                     data-aos="fade-up" data-aos-delay="<?php echo e(($index % 3) * 100); ?>">
                    <div class="portfolio-card">
                        <div class="portfolio-card-image">
                            <?php if($portfolio->image): ?>
                                <img src="<?php echo e(asset($portfolio->image)); ?>" alt="<?php echo e($portfolio->title); ?>" loading="lazy">
                            <?php else: ?>
                                <div class="portfolio-placeholder">
                                    <i class="bi bi-layers"></i>
                                </div>
                            <?php endif; ?>
                            <div class="portfolio-overlay">
                                <div class="portfolio-overlay-content">
                                    <?php if($portfolio->link): ?>
                                        <a href="<?php echo e($portfolio->link); ?>" class="portfolio-view-btn" target="_blank">
                                            <i class="bi bi-arrow-up-right"></i>
                                            View Project
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php if($portfolio->category): ?>
                                <span class="portfolio-badge"><?php echo e($portfolio->category); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="portfolio-card-body">
                            <h5 class="portfolio-title"><?php echo e($portfolio->title); ?></h5>
                            <?php if($portfolio->description): ?>
                                <p class="portfolio-desc"><?php echo e(Str::limit($portfolio->description, 90)); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if($portfolios->count() > 6): ?>
        <div class="text-center mt-5" id="loadMoreWrapper" data-aos="fade-up">
            <button class="btn-load-more" id="portfolioLoadMore">
                <i class="bi bi-grid me-2"></i>
                <span id="loadMoreText">Load More Projects</span>
                <span class="load-more-count">(<?php echo e($portfolios->count() - 6); ?> more)</span>
            </button>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Experience Section -->
<section class="section-padding" id="experience">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-up">
            <span class="section-badge">
                <i class="bi bi-clock-history me-1"></i> My journey
            </span>
            <h2 class="section-title">Experience</h2>
            <p class="section-subtitle">Where I've worked and what I've learned along the way</p>
        </div>

        <?php if($experiences->count() > 0): ?>
        <div class="exp-timeline">
            <div class="exp-line"></div>
            <?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="exp-item <?php echo e($loop->even ? 'exp-right' : 'exp-left'); ?>" data-aos="fade-<?php echo e($loop->even ? 'left' : 'right'); ?>">
                <div class="exp-connector"></div>
                <div class="exp-node">
                    <span class="exp-node-num"><?php echo e(str_pad($loop->iteration, 2, '0', STR_PAD_LEFT)); ?></span>
                </div>
                <div class="exp-card">
                    <div class="exp-card-header">
                        <div class="exp-period">
                            <i class="bi bi-calendar-range"></i>
                            <?php echo e($experience->period); ?>

                        </div>
                        <div class="exp-icon-wrap">
                            <i class="bi bi-building-fill"></i>
                        </div>
                    </div>
                    <h4 class="exp-title"><?php echo e($experience->title); ?></h4>
                    <div class="exp-company">
                        <i class="bi bi-geo-alt"></i>
                        <?php echo e($experience->company); ?>

                    </div>
                    <?php if($experience->description): ?>
                        <p class="exp-desc"><?php echo e($experience->description); ?></p>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
        <div class="text-center py-5 text-muted">
            <i class="bi bi-briefcase" style="font-size:3rem; opacity:0.3"></i>
            <p class="mt-3">No experience added yet.</p>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- GitHub Repos Section -->
<?php if(isset($settings['github_username']) && $settings['github_username'] != ''): ?>
<section class="section-padding bg-light-custom" id="github">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-up">
            <span class="section-badge">
                <i class="bi bi-github me-1"></i> Open Source
            </span>
            <h2 class="section-title">GitHub Repositories</h2>
        </div>

        <div class="row g-4 align-items-start">
            
            <div class="col-lg-3 col-md-4" data-aos="fade-right">
                <div class="gh-profile-card" id="gh-profile-card">
                    <div class="gh-loading">
                        <div class="gh-spinner"></div>
                        <span>Loading...</span>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-9 col-md-8">
                <div class="gh-repos-grid" id="github-repos-container"
                     data-github-username="<?php echo e($settings['github_username']); ?>">
                    <div class="gh-loading" style="grid-column:1/-1" id="github-loading">
                        <div class="gh-spinner"></div>
                        <span>Loading repositories...</span>
                    </div>
                </div>

                <div class="text-center mt-4" data-aos="fade-up">
                    <a href="https://github.com/<?php echo e($settings['github_username']); ?>" target="_blank" class="btn btn-outline-custom">
                        <i class="bi bi-github me-2"></i>View All on GitHub
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Contact Section -->
<section class="section-padding bg-light-custom position-relative" id="contact">
    <!-- Background Decor -->
    <div class="position-absolute top-0 end-0 mt-5 me-5 d-none d-lg-block" style="width: 300px; height: 300px; background: radial-gradient(circle, rgba(37,99,235,0.05) 0%, transparent 70%); border-radius: 50%; z-index: 0;"></div>
    
    <div class="container position-relative" style="z-index: 1;">
        <div class="text-center mb-5" data-aos="fade-up">
            <span class="section-badge">
                <i class="bi bi-envelope me-1"></i> Reach out
            </span>
            <h2 class="section-title">Get In Touch</h2>
            <p class="section-subtitle">Have a project in mind or just want to say hi? I'd love to hear from you.</p>
        </div>

        <div class="row g-5">
            <!-- Left Info Column -->
            <div class="col-lg-5" data-aos="fade-right">
                <div class="contact-info-wrapper">
                    <h3 class="mb-4 fw-bold" style="font-size: 1.8rem; color: var(--dark); letter-spacing: -0.5px;">Let's talk about your next project.</h3>
                    <p class="mb-5 text-muted">Fill out the form and I will get back to you within 24 hours. Or simply reach out via email.</p>

                    <div class="d-flex flex-column gap-4">
                        <div class="contact-item d-flex align-items-center p-3 rounded-4" style="background: var(--white); border: 1px solid var(--border); box-shadow: 0 4px 15px rgba(0,0,0,0.03); transition: all 0.3s;">
                            <div class="contact-icon-box me-3 d-flex align-items-center justify-content-center rounded-circle" style="width: 50px; height: 50px; background: rgba(37,99,235,0.1); color: var(--primary); font-size: 1.2rem;">
                                <i class="bi bi-envelope-fill"></i>
                            </div>
                            <div>
                                <h6 class="mb-1 fw-bold text-dark">Email Me</h6>
                                <p class="mb-0 text-muted" style="font-size: 0.9rem;">
                                    <?php if(!empty($settings['contact_email'])): ?>
                                        <a href="mailto:<?php echo e($settings['contact_email']); ?>" class="text-decoration-none text-muted contact-link"><?php echo e($settings['contact_email']); ?></a>
                                    <?php else: ?>
                                        hello@example.com
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>

                        <div class="contact-item d-flex align-items-center p-3 rounded-4" style="background: var(--white); border: 1px solid var(--border); box-shadow: 0 4px 15px rgba(0,0,0,0.03); transition: all 0.3s;">
                            <div class="contact-icon-box me-3 d-flex align-items-center justify-content-center rounded-circle" style="width: 50px; height: 50px; background: rgba(124,58,237,0.1); color: #7C3AED; font-size: 1.2rem;">
                                <i class="bi bi-geo-alt-fill"></i>
                            </div>
                            <div>
                                <h6 class="mb-1 fw-bold text-dark">Location</h6>
                                <p class="mb-0 text-muted" style="font-size: 0.9rem;"><?php echo e($settings['contact_address'] ?? 'Jakarta, Indonesia'); ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Social Links -->
                    <div class="mt-5">
                        <h6 class="fw-bold mb-3 text-dark">Connect with me</h6>
                        <div class="d-flex gap-3">
                            <?php $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($link->url); ?>" target="_blank" class="contact-social-btn d-flex align-items-center justify-content-center rounded-circle" title="<?php echo e($link->platform); ?>" style="width: 45px; height: 45px; background: var(--white); border: 1px solid var(--border); color: var(--text); font-size: 1.1rem; transition: all 0.3s;">
                                    <i class="bi bi-<?php echo e($link->icon); ?>"></i>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Form Column -->
            <div class="col-lg-7" data-aos="fade-left">
                <div class="contact-form-card p-4 p-md-5 rounded-4" style="background: var(--white); border: 1px solid var(--border); box-shadow: 0 20px 40px rgba(0,0,0,0.05); position: relative; overflow: hidden;">
                    <!-- Decorative line -->
                    <div class="position-absolute top-0 start-0 w-100" style="height: 4px; background: var(--gradient);"></div>
                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('contact.send')); ?>" method="POST" class="contact-form">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold" style="font-size: 0.9rem;">Your Name</label>
                                <input type="text" name="name" class="form-control form-control-lg bg-light-custom border-0 custom-input <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="John Doe" value="<?php echo e(old('name')); ?>" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold" style="font-size: 0.9rem;">Email Address</label>
                                <input type="email" name="email" class="form-control form-control-lg bg-light-custom border-0 custom-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="john@example.com" value="<?php echo e(old('email')); ?>" required>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 mt-4">
                                <label class="form-label fw-semibold" style="font-size: 0.9rem;">Subject</label>
                                <input type="text" name="subject" class="form-control form-control-lg bg-light-custom border-0 custom-input <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Project Inquiry" value="<?php echo e(old('subject')); ?>" required>
                                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 mt-4">
                                <label class="form-label fw-semibold" style="font-size: 0.9rem;">Message</label>
                                <textarea name="message" class="form-control form-control-lg bg-light-custom border-0 custom-input <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="4" placeholder="Tell me about your project..." required><?php echo e(old('message')); ?></textarea>
                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 mt-4">
                                <div class="g-recaptcha" data-sitekey="<?php echo e(env('RECAPTCHA_SITE_KEY')); ?>"></div>
                                <?php $__errorArgs = ['g-recaptcha-response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1 small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 mt-4">
                                <button type="submit" class="btn btn-primary-custom w-100 py-3 d-flex align-items-center justify-content-center gap-2">
                                    <i class="bi bi-send-fill"></i> Send Message
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="site-footer">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-4">
                <div class="footer-brand">
                    <i class="bi bi-hexagon-fill me-2"></i><?php echo e($settings['site_name'] ?? 'Porto'); ?>

                </div>
            </div>
            <div class="col-md-4 text-center">
                <div class="footer-social">
                    <?php $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($link->url); ?>" target="_blank" title="<?php echo e($link->platform); ?>">
                            <i class="bi bi-<?php echo e($link->icon); ?>"></i>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-4 text-md-end">
                <?php
                    $footerText = $settings['footer_text'] ?? '© ' . date('Y') . ' Porto. All rights reserved.';
                    $dynamicFooter = preg_replace('/\b20\d{2}\b/', date('Y'), $footerText);
                ?>
                <p class="footer-text"><?php echo e($dynamicFooter); ?></p>
            </div>
        </div>
    </div>
</footer>

<?php $__env->startPush('scripts'); ?>
<script>
    // ===== Dark/Light Mode Toggle =====
    const themeToggle = document.getElementById('themeToggle');
    const htmlElement = document.documentElement;

    // Load saved theme or detect system preference
    function getPreferredTheme() {
        const saved = localStorage.getItem('porto-theme');
        if (saved) return saved;
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }

    function setTheme(theme) {
        htmlElement.setAttribute('data-theme', theme);
        localStorage.setItem('porto-theme', theme);
    }

    // Apply theme on load (no flash)
    setTheme(getPreferredTheme());

    // Toggle on click
    themeToggle.addEventListener('click', function() {
        const current = htmlElement.getAttribute('data-theme');
        const next = current === 'dark' ? 'light' : 'dark';
        setTheme(next);
    });

    // Listen for system theme changes
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
        if (!localStorage.getItem('porto-theme')) {
            setTheme(e.matches ? 'dark' : 'light');
        }
    });

    // ===== Navbar scroll effect & Active Menu Spy =====
    const sections = document.querySelectorAll('section');
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');

    window.addEventListener('scroll', function() {
        const navbar = document.getElementById('mainNavbar');
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }

        let current = '';
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            // Subtract offset to trigger earlier (e.g., when navbar height is considered)
            if (scrollY >= (sectionTop - 120)) {
                current = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });

    // Smooth scroll
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                const navCollapse = document.querySelector('.navbar-collapse');
                if (navCollapse.classList.contains('show')) {
                    new bootstrap.Collapse(navCollapse).hide();
                }
            }
        });
    });

    // Scroll reveal animation
    const revealElements = document.querySelectorAll('[data-aos]');
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const delay = entry.target.getAttribute('data-aos-delay') || 0;
                setTimeout(() => {
                    entry.target.classList.add('aos-animate');
                }, delay);
                revealObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    revealElements.forEach(el => revealObserver.observe(el));

    // Portfolio filter + Load More
    const filterBtns = document.querySelectorAll('.filter-btn');
    const portfolioItems = document.querySelectorAll('.portfolio-item');
    const loadMoreBtn = document.getElementById('portfolioLoadMore');
    const loadMoreWrapper = document.getElementById('loadMoreWrapper');
    let currentFilter = 'all';
    const PAGE_SIZE = 6;

    function applyFilter(filter) {
        currentFilter = filter;
        let visible = 0;
        portfolioItems.forEach(item => {
            const matchesFilter = filter === 'all' || item.getAttribute('data-category') === filter;
            if (matchesFilter) {
                visible++;
                if (visible <= PAGE_SIZE) {
                    item.style.display = '';
                    item.classList.remove('portfolio-hidden');
                    item.classList.add('aos-animate');
                } else {
                    item.style.display = 'none';
                    item.classList.add('portfolio-hidden');
                }
            } else {
                item.style.display = 'none';
            }
        });

        // Update load more button
        const totalMatchingFilter = Array.from(portfolioItems).filter(item =>
            filter === 'all' || item.getAttribute('data-category') === filter
        ).length;

        if (loadMoreWrapper) {
            if (totalMatchingFilter > PAGE_SIZE) {
                loadMoreWrapper.style.display = '';
                const remaining = totalMatchingFilter - PAGE_SIZE;
                document.getElementById('loadMoreText').textContent = 'Load More Projects';
                document.querySelector('.load-more-count').textContent = `(${remaining} more)`;
            } else {
                loadMoreWrapper.style.display = 'none';
            }
        }
    }

    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            applyFilter(this.getAttribute('data-filter'));
        });
    });

    // Load More
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            const hiddenItems = Array.from(portfolioItems).filter(item => {
                const matchesFilter = currentFilter === 'all' || item.getAttribute('data-category') === currentFilter;
                return matchesFilter && (item.style.display === 'none' || item.classList.contains('portfolio-hidden'));
            });

            hiddenItems.slice(0, PAGE_SIZE).forEach(item => {
                item.style.display = '';
                item.classList.remove('portfolio-hidden');
                item.classList.add('aos-animate');
            });

            const stillHidden = hiddenItems.slice(PAGE_SIZE).length;
            if (stillHidden === 0 && loadMoreWrapper) {
                loadMoreWrapper.style.display = 'none';
            } else if (loadMoreWrapper) {
                document.querySelector('.load-more-count').textContent = `(${stillHidden} more)`;
            }
        });
    }

    // Init filter on page load
    applyFilter('all');

    // Fetch GitHub Profile
    const ghProfileCard = document.getElementById('gh-profile-card');
    const githubContainer = document.getElementById('github-repos-container');

    const langColors = {
        JavaScript: '#F7DF1E', TypeScript: '#3178C6', PHP: '#777BB4',
        Python: '#3776AB', HTML: '#E34F26', CSS: '#1572B6',
        Vue: '#42B883', Java: '#ED8B00', 'C#': '#239120',
        Ruby: '#CC342D', Go: '#00ADD8', Rust: '#DEA584',
        Kotlin: '#7F52FF', Swift: '#F05138', Dart: '#0175C2'
    };
    function langColor(lang) { return langColors[lang] || '#94A3B8'; }

    if (githubContainer) {
        const username = githubContainer.getAttribute('data-github-username');
        if (username) {

            // Profile
            if (ghProfileCard) {
                fetch(`https://api.github.com/users/${username}`)
                    .then(r => r.json())
                    .then(user => {
                        ghProfileCard.innerHTML = `
                            <img src="${user.avatar_url}" alt="${user.login}" class="gh-avatar" loading="lazy">
                            <div class="gh-profile-info">
                                <h3 class="gh-username">${user.name || user.login}</h3>
                                <p class="gh-login">@${user.login}</p>
                                ${ user.bio ? `<p class="gh-bio">${user.bio}</p>` : '' }
                                <a href="${user.html_url}" target="_blank" class="gh-follow-btn">
                                    <i class="bi bi-github"></i> View on GitHub
                                </a>
                                <div class="gh-meta">
                                    <div class="gh-meta-item">
                                        <i class="bi bi-people-fill"></i>
                                        <span>${user.followers} <small>followers</small></span>
                                        <span class="mx-1">&middot;</span>
                                        <span>${user.following} <small>following</small></span>
                                    </div>
                                    ${ user.location ? `<div class="gh-meta-item"><i class="bi bi-geo-alt-fill"></i><span>${user.location}</span></div>` : '' }
                                    ${ user.public_repos !== undefined ? `<div class="gh-meta-item"><i class="bi bi-journal-code"></i><span>${user.public_repos} public repos</span></div>` : '' }
                                </div>
                            </div>`;
                    })
                    .catch(() => { ghProfileCard.style.display = 'none'; });
            }

            // Repos
            fetch(`https://api.github.com/users/${username}/repos?sort=updated&per_page=6&type=public`)
                .then(response => {
                    if (!response.ok) throw new Error('Network response was not ok');
                    return response.json();
                })
                .then(repos => {
                    const loadingEl = document.getElementById('github-loading');
                    if (loadingEl) loadingEl.remove();
                    if (!repos || repos.length === 0) {
                        githubContainer.innerHTML = '<div class="gh-loading">No public repositories found.</div>';
                        return;
                    }
                    let html = '';
                    repos.slice(0, 6).forEach(repo => {
                        const desc = repo.description
                            ? repo.description.substring(0, 90) + (repo.description.length > 90 ? '…' : '')
                            : '<em style="opacity:0.45">No description</em>';
                        html += `
                        <a href="${repo.html_url}" target="_blank" class="gh-repo-card">
                            <div class="gh-repo-name">${repo.name}</div>
                            <div class="gh-repo-desc">${desc}</div>
                            <div class="gh-repo-stats">
                                <span class="gh-repo-stat"><i class="bi bi-star"></i>${repo.stargazers_count}</span>
                                <span class="gh-repo-stat"><i class="bi bi-diagram-2"></i>${repo.forks_count}</span>
                                ${ repo.language ? `<span class="gh-repo-lang"><span class="lang-dot" style="background:${langColor(repo.language)}"></span>${repo.language}</span>` : '' }
                            </div>
                        </a>`;
                    });
                    githubContainer.innerHTML = html;
                })
                .catch(error => {
                    const loadingEl = document.getElementById('github-loading');
                    if (loadingEl) loadingEl.remove();
                    githubContainer.innerHTML = '<div class="gh-loading" style="color:var(--text-light)">Failed to load repositories.</div>';
                    console.error('Error fetching GitHub repos:', error);
                });
        }
    }
</script>
<?php $__env->stopPush(); ?>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\HERD\porto\resources\views/landing/index.blade.php ENDPATH**/ ?>